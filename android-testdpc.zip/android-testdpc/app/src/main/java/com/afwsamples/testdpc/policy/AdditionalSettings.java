package com.afwsamples.testdpc.policy;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PermissionInfo;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.preference.Preference;

import com.afwsamples.testdpc.DeviceAdminReceiver;
import com.afwsamples.testdpc.R;
import com.afwsamples.testdpc.common.BaseSearchablePolicyPreferenceFragment;
import com.afwsamples.testdpc.common.Util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static android.app.admin.DevicePolicyManager.PERMISSION_GRANT_STATE_GRANTED;
import static com.afwsamples.testdpc.DeviceAdminReceiver.getComponentName;


@TargetApi(Build.VERSION_CODES.P)
public class AdditionalSettings extends BaseSearchablePolicyPreferenceFragment implements
        Preference.OnPreferenceClickListener{

    private static String LOG_TAG = "AdditionalSettingsFragment";
    private static final String GRANT_ALL_PERMISSION_APN_KEY = "grant_all_permission";
    private static final String CHECK_PERMISSION_APN_KEY = "check_permission_state";
    private static final String VERIFY_DIRECT_DOWNLOAD_KEY = "verify-direct-download";


    private  Context mContext;

    private DevicePolicyManager mDevicePolicyManager;
    private ComponentName mAdminComponentName;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        mDevicePolicyManager = (DevicePolicyManager) getActivity().getSystemService(
                Context.DEVICE_POLICY_SERVICE);
        mAdminComponentName = DeviceAdminReceiver.getComponentName(getActivity());
        getActivity().getActionBar().setTitle(R.string.additional_settings_title);
        mContext = getActivity().getApplicationContext();
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        addPreferencesFromResource(R.xml.additional_settings_preference);

        findPreference(GRANT_ALL_PERMISSION_APN_KEY).setOnPreferenceClickListener(this);
        findPreference(CHECK_PERMISSION_APN_KEY).setOnPreferenceClickListener(this);
        findPreference(VERIFY_DIRECT_DOWNLOAD_KEY).setOnPreferenceClickListener(this);

    }

    @Override
    public boolean isAvailable(Context context) {
        return true;
    }

    @Override
    public boolean onPreferenceClick(Preference preference) {
        String key = preference.getKey();
        switch (key) {
            case GRANT_ALL_PERMISSION_APN_KEY:
                if (Util.SDK_INT >= Build.VERSION_CODES.M) {
                    autoGrantRequestedPermissionsToSelf();
                }
                return true;
            case CHECK_PERMISSION_APN_KEY:
                if (Util.SDK_INT >= Build.VERSION_CODES.M) {
                    dumpPermissions();
                }
                return true;
            case VERIFY_DIRECT_DOWNLOAD_KEY:
                fileOperations();
                return true;
        }
        return false;
    }

    private void fileOperations()
    {
        createAndUpdateFileViaFileWriter(mContext, "ViaJavaIOStream.txt","Hello enterprise_usr", "/sdcard");
        createAndUpdateFileViaFileApi(mContext, "ViaJavaCreateFile.txt","Hello enterprise_usr", "/sdcard");
        createAndUpdateFileViaFileApi(mContext, "ViaJavaCreateFile.txt","Hello enterprise_usr", "/storage/emulated/0");
        createAndUpdateFileCreateException(mContext, "Createatroot.txt","Hello enterprise_usr", "/sdcard");
        /*
        createDirectory(mContext, "NitinTestDir", "/sdcard");
        createAndUpdateFile(mContext, "myhello.txt","Hello enterprise_usr", "/sdcard/NitinTestDir");
        createAndUpdateFile(mContext, "myhello1.txt","Hello enterprise_usr1", "/sdcard/NitinTestDir");

        createDirectory(mContext, "NitinTestDirDL", "/sdcard/Download");
        createAndUpdateFile(mContext, "myhello.txt","Hello enterprise_usr", "/sdcard/Download/NitinTestDirDL");
        createAndUpdateFile(mContext, "myhello1.txt","Hello enterprise_usr1", "/sdcard/Download/NitinTestDirDL");

         */

    }

    public void createDirectory(Context context, String sFileName, String path){

        File gpxfile = new File(path, sFileName);
        gpxfile.mkdirs();
        //Toast.makeText(context, "Saved", Toast.LENGTH_SHORT).show();

    }

    public void createAndUpdateFileCreateException(Context context, String sFileName, String sBody, String path) {
        try {
            boolean result;
            File gpxfile = new File(sFileName);
            result = gpxfile.createNewFile();
            BufferedWriter buf = new BufferedWriter(new FileWriter(gpxfile, true));
            buf.append(sBody);
            buf.newLine();
            buf.close();
            // Toast.makeText(context, "Saved", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void createAndUpdateFileViaFileApi(Context context, String sFileName, String sBody, String path) {
        try {
            boolean result;
            File gpxfile = new File(path, sFileName);
            result = gpxfile.createNewFile();
            BufferedWriter buf = new BufferedWriter(new FileWriter(gpxfile, true));
            buf.append(sBody);
            buf.newLine();
            buf.close();
            // Toast.makeText(context, "Saved", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void createAndUpdateFileViaFileWriter(Context context, String sFileName, String sBody, String path) {
        try {
            File gpxfile = new File(path, sFileName);
            FileWriter writer = new FileWriter(gpxfile);
            writer.append(sBody);
            writer.flush();
            writer.close();
            gpxfile.setWritable(true,false);
            gpxfile.setReadable(true,false);
           // Toast.makeText(context, "Saved", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private void showToast(int msgId, Object... args) {
        showToast(getString(msgId, args), Toast.LENGTH_SHORT);
    }

    private void showToast(String msg) {
        showToast(msg, Toast.LENGTH_SHORT);
    }

    private void showToast(String msg, int duration) {
        Activity activity = getActivity();
        if (activity == null || activity.isFinishing()) {
            return;
        }
        Toast.makeText(activity, msg, duration).show();
    }


    private void dumpPermissions() {
        String packageName = mContext.getPackageName();
        ComponentName adminComponentName = getComponentName(mContext);

        List<String> permissions = getRuntimePermissions(mContext.getPackageManager(), packageName);
        for (String permission : permissions) {
            int success = mDevicePolicyManager.getPermissionGrantState(adminComponentName,
                    packageName, permission);

            Log.d(LOG_TAG, "Permission state  " + permission + ", success: " + success);

            }
        }


    @TargetApi(Build.VERSION_CODES.M)
    private void autoGrantRequestedPermissionsToSelf() {
        String packageName = mContext.getPackageName();
        ComponentName adminComponentName = getComponentName(mContext);

        List<String> permissions = getRuntimePermissions(mContext.getPackageManager(), packageName);
        for (String permission : permissions) {
            boolean success = mDevicePolicyManager.setPermissionGrantState(adminComponentName,
                    packageName, permission, PERMISSION_GRANT_STATE_GRANTED);
            Log.d(LOG_TAG, "Auto-granting " + permission + ", success: " + success);
            if (!success) {
                Log.e(LOG_TAG, "Failed to auto grant permission to self: " + permission);
            }
        }
    }

    private List<String> getRuntimePermissions(PackageManager packageManager, String packageName) {
        List<String> permissions = new ArrayList<>();
        PackageInfo packageInfo;
        try {
            packageInfo =
                    packageManager.getPackageInfo(packageName, PackageManager.GET_PERMISSIONS);
        } catch (PackageManager.NameNotFoundException e) {
            Log.e(LOG_TAG, "Could not retrieve info about the package: " + packageName, e);
            return permissions;
        }

        if (packageInfo != null && packageInfo.requestedPermissions != null) {
            for (String requestedPerm : packageInfo.requestedPermissions) {
                if (isRuntimePermission(packageManager, requestedPerm)) {
                    permissions.add(requestedPerm);
                }
            }
        }
        return permissions;
    }

    private boolean isRuntimePermission(PackageManager packageManager, String permission) {
        try {
            PermissionInfo pInfo = packageManager.getPermissionInfo(permission, 0);
            if (pInfo != null) {
                if ((pInfo.protectionLevel & PermissionInfo.PROTECTION_MASK_BASE)
                        == PermissionInfo.PROTECTION_DANGEROUS) {
                    return true;
                }
            }
        } catch (PackageManager.NameNotFoundException e) {
            Log.i(LOG_TAG, "Could not retrieve info about the permission: " + permission);
        }
        return false;
    }
}
